<?php
$host="localhost";
$user="root";
$pass="";
$db="uni";
$con=mysqli_connect("$host","$user","$pass","$db") or die ("fatal error".'<a href="contact.html>'." contact admin".'</a>');

?>