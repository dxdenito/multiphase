<?php
$county=$_POST['county'];

?>